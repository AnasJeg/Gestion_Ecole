﻿namespace Gestion_Ecole.userControle
{
    partial class Student
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Student));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.delete = new Guna.UI2.WinForms.Guna2Button();
            this.update = new Guna.UI2.WinForms.Guna2Button();
            this.add = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.upload = new Guna.UI2.WinForms.Guna2Button();
            this.picEtud = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.Ttell = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.combVille = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.dateN = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.man = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.women = new Guna.UI2.WinForms.Guna2ImageRadioButton();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.NumAge = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Tcne = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tadresse = new Guna.UI2.WinForms.Guna2TextBox();
            this.Temail = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tcin = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tp = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tn = new Guna.UI2.WinForms.Guna2TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.combFilier = new Guna.UI2.WinForms.Guna2ComboBox();
            this.NumGroupe = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.NumAnne = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            this.guna2GroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEtud)).BeginInit();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumAge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumGroupe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAnne)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1080, 703);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.delete);
            this.tabPage1.Controls.Add(this.update);
            this.tabPage1.Controls.Add(this.add);
            this.tabPage1.Controls.Add(this.guna2GroupBox3);
            this.tabPage1.Controls.Add(this.guna2GroupBox2);
            this.tabPage1.Controls.Add(this.guna2GroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1072, 670);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ajouter Etudiant";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // delete
            // 
            this.delete.BorderRadius = 20;
            this.delete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.delete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.delete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.delete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.delete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.delete.ForeColor = System.Drawing.Color.White;
            this.delete.Location = new System.Drawing.Point(871, 523);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(135, 45);
            this.delete.TabIndex = 20;
            this.delete.Text = "Supprimer";
            // 
            // update
            // 
            this.update.BorderRadius = 20;
            this.update.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.update.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.update.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.update.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.update.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.update.ForeColor = System.Drawing.Color.White;
            this.update.Location = new System.Drawing.Point(686, 523);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(135, 45);
            this.update.TabIndex = 19;
            this.update.Text = "Modifier";
            // 
            // add
            // 
            this.add.BorderRadius = 20;
            this.add.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.add.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.add.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.add.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.add.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.add.ForeColor = System.Drawing.Color.White;
            this.add.Location = new System.Drawing.Point(487, 523);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(135, 45);
            this.add.TabIndex = 18;
            this.add.Text = "Ajouter";
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.Controls.Add(this.guna2HtmlLabel8);
            this.guna2GroupBox3.Controls.Add(this.NumAnne);
            this.guna2GroupBox3.Controls.Add(this.guna2HtmlLabel7);
            this.guna2GroupBox3.Controls.Add(this.guna2HtmlLabel6);
            this.guna2GroupBox3.Controls.Add(this.guna2HtmlLabel5);
            this.guna2GroupBox3.Controls.Add(this.NumGroupe);
            this.guna2GroupBox3.Controls.Add(this.combFilier);
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox3.Location = new System.Drawing.Point(497, 258);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.Size = new System.Drawing.Size(519, 227);
            this.guna2GroupBox3.TabIndex = 2;
            this.guna2GroupBox3.Text = "Etudes";
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.Controls.Add(this.upload);
            this.guna2GroupBox2.Controls.Add(this.picEtud);
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox2.Location = new System.Drawing.Point(497, 17);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.Size = new System.Drawing.Size(519, 235);
            this.guna2GroupBox2.TabIndex = 1;
            this.guna2GroupBox2.Text = "Photo";
            // 
            // upload
            // 
            this.upload.BorderRadius = 20;
            this.upload.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.upload.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.upload.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.upload.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.upload.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.upload.ForeColor = System.Drawing.Color.White;
            this.upload.Location = new System.Drawing.Point(319, 80);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(135, 45);
            this.upload.TabIndex = 19;
            this.upload.Text = "Upload";
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // picEtud
            // 
            this.picEtud.BorderRadius = 11;
            this.picEtud.ImageRotate = 0F;
            this.picEtud.Location = new System.Drawing.Point(34, 57);
            this.picEtud.Name = "picEtud";
            this.picEtud.Size = new System.Drawing.Size(243, 166);
            this.picEtud.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEtud.TabIndex = 0;
            this.picEtud.TabStop = false;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.Ttell);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GroupBox1.Controls.Add(this.combVille);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GroupBox1.Controls.Add(this.dateN);
            this.guna2GroupBox1.Controls.Add(this.man);
            this.guna2GroupBox1.Controls.Add(this.women);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GroupBox1.Controls.Add(this.NumAge);
            this.guna2GroupBox1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GroupBox1.Controls.Add(this.Tcne);
            this.guna2GroupBox1.Controls.Add(this.Tadresse);
            this.guna2GroupBox1.Controls.Add(this.Temail);
            this.guna2GroupBox1.Controls.Add(this.Tcin);
            this.guna2GroupBox1.Controls.Add(this.Tp);
            this.guna2GroupBox1.Controls.Add(this.Tn);
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox1.Location = new System.Drawing.Point(7, 17);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(442, 657);
            this.guna2GroupBox1.TabIndex = 0;
            this.guna2GroupBox1.Text = "Information";
            // 
            // Ttell
            // 
            this.Ttell.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Ttell.DefaultText = "";
            this.Ttell.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Ttell.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Ttell.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Ttell.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Ttell.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Ttell.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Ttell.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Ttell.Location = new System.Drawing.Point(12, 515);
            this.Ttell.Name = "Ttell";
            this.Ttell.PasswordChar = '\0';
            this.Ttell.PlaceholderText = "Tell";
            this.Ttell.SelectedText = "";
            this.Ttell.Size = new System.Drawing.Size(399, 36);
            this.Ttell.TabIndex = 28;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(9, 462);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(40, 23);
            this.guna2HtmlLabel3.TabIndex = 27;
            this.guna2HtmlLabel3.Text = "Ville : ";
            // 
            // combVille
            // 
            this.combVille.BackColor = System.Drawing.Color.Transparent;
            this.combVille.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.combVille.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combVille.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.combVille.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.combVille.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.combVille.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.combVille.ItemHeight = 30;
            this.combVille.Location = new System.Drawing.Point(152, 462);
            this.combVille.Name = "combVille";
            this.combVille.Size = new System.Drawing.Size(259, 36);
            this.combVille.TabIndex = 26;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(0, 403);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(134, 23);
            this.guna2HtmlLabel4.TabIndex = 25;
            this.guna2HtmlLabel4.Text = "Date de naissance :";
            // 
            // dateN
            // 
            this.dateN.BorderRadius = 11;
            this.dateN.Checked = true;
            this.dateN.FillColor = System.Drawing.Color.White;
            this.dateN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dateN.ForeColor = System.Drawing.Color.Black;
            this.dateN.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dateN.Location = new System.Drawing.Point(152, 403);
            this.dateN.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dateN.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dateN.Name = "dateN";
            this.dateN.Size = new System.Drawing.Size(259, 36);
            this.dateN.TabIndex = 23;
            this.dateN.Value = new System.DateTime(2023, 1, 7, 21, 59, 7, 235);
            // 
            // man
            // 
            this.man.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
            this.man.Image = global::Gestion_Ecole.Properties.Resources.man;
            this.man.ImageOffset = new System.Drawing.Point(0, 0);
            this.man.ImageRotate = 0F;
            this.man.Location = new System.Drawing.Point(149, 325);
            this.man.Name = "man";
            this.man.Size = new System.Drawing.Size(61, 39);
            this.man.TabIndex = 22;
            // 
            // women
            // 
            this.women.CheckedState.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
            this.women.Image = global::Gestion_Ecole.Properties.Resources.woman;
            this.women.ImageOffset = new System.Drawing.Point(0, 0);
            this.women.ImageRotate = 0F;
            this.women.Location = new System.Drawing.Point(253, 326);
            this.women.Name = "women";
            this.women.Size = new System.Drawing.Size(84, 38);
            this.women.TabIndex = 21;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(12, 284);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(37, 23);
            this.guna2HtmlLabel2.TabIndex = 19;
            this.guna2HtmlLabel2.Text = "Age : ";
            // 
            // NumAge
            // 
            this.NumAge.BackColor = System.Drawing.Color.Transparent;
            this.NumAge.BorderRadius = 11;
            this.NumAge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NumAge.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NumAge.Location = new System.Drawing.Point(127, 277);
            this.NumAge.Name = "NumAge";
            this.NumAge.Size = new System.Drawing.Size(284, 30);
            this.NumAge.TabIndex = 18;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(12, 341);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(42, 23);
            this.guna2HtmlLabel1.TabIndex = 17;
            this.guna2HtmlLabel1.Text = "Sexe :";
            // 
            // Tcne
            // 
            this.Tcne.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tcne.DefaultText = "";
            this.Tcne.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tcne.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tcne.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tcne.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tcne.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tcne.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tcne.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tcne.Location = new System.Drawing.Point(234, 156);
            this.Tcne.Name = "Tcne";
            this.Tcne.PasswordChar = '\0';
            this.Tcne.PlaceholderText = "CNE";
            this.Tcne.SelectedText = "";
            this.Tcne.Size = new System.Drawing.Size(177, 28);
            this.Tcne.TabIndex = 16;
            // 
            // Tadresse
            // 
            this.Tadresse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tadresse.DefaultText = "";
            this.Tadresse.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tadresse.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tadresse.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tadresse.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tadresse.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tadresse.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tadresse.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tadresse.Location = new System.Drawing.Point(12, 573);
            this.Tadresse.Name = "Tadresse";
            this.Tadresse.PasswordChar = '\0';
            this.Tadresse.PlaceholderText = "Adresse";
            this.Tadresse.SelectedText = "";
            this.Tadresse.Size = new System.Drawing.Size(399, 64);
            this.Tadresse.TabIndex = 15;
            // 
            // Temail
            // 
            this.Temail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Temail.DefaultText = "";
            this.Temail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Temail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Temail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Temail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Temail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Temail.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Temail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Temail.Location = new System.Drawing.Point(12, 218);
            this.Temail.Name = "Temail";
            this.Temail.PasswordChar = '\0';
            this.Temail.PlaceholderText = "Email";
            this.Temail.SelectedText = "";
            this.Temail.Size = new System.Drawing.Size(399, 28);
            this.Temail.TabIndex = 14;
            // 
            // Tcin
            // 
            this.Tcin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tcin.DefaultText = "";
            this.Tcin.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tcin.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tcin.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tcin.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tcin.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tcin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tcin.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tcin.Location = new System.Drawing.Point(12, 156);
            this.Tcin.Name = "Tcin";
            this.Tcin.PasswordChar = '\0';
            this.Tcin.PlaceholderText = "CIN";
            this.Tcin.SelectedText = "";
            this.Tcin.Size = new System.Drawing.Size(177, 28);
            this.Tcin.TabIndex = 13;
            // 
            // Tp
            // 
            this.Tp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tp.DefaultText = "";
            this.Tp.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tp.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tp.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tp.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tp.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tp.Location = new System.Drawing.Point(234, 97);
            this.Tp.Name = "Tp";
            this.Tp.PasswordChar = '\0';
            this.Tp.PlaceholderText = "Prenom";
            this.Tp.SelectedText = "";
            this.Tp.Size = new System.Drawing.Size(177, 28);
            this.Tp.TabIndex = 12;
            // 
            // Tn
            // 
            this.Tn.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tn.DefaultText = "";
            this.Tn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tn.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tn.Location = new System.Drawing.Point(12, 97);
            this.Tn.Name = "Tn";
            this.Tn.PasswordChar = '\0';
            this.Tn.PlaceholderText = "Nom ";
            this.Tn.SelectedText = "";
            this.Tn.Size = new System.Drawing.Size(177, 28);
            this.Tn.TabIndex = 11;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1072, 670);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // combFilier
            // 
            this.combFilier.BackColor = System.Drawing.Color.Transparent;
            this.combFilier.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.combFilier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combFilier.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.combFilier.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.combFilier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.combFilier.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.combFilier.ItemHeight = 30;
            this.combFilier.Location = new System.Drawing.Point(195, 74);
            this.combFilier.Name = "combFilier";
            this.combFilier.Size = new System.Drawing.Size(229, 36);
            this.combFilier.TabIndex = 27;
            // 
            // NumGroupe
            // 
            this.NumGroupe.BackColor = System.Drawing.Color.Transparent;
            this.NumGroupe.BorderRadius = 11;
            this.NumGroupe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NumGroupe.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NumGroupe.Location = new System.Drawing.Point(195, 168);
            this.NumGroupe.Name = "NumGroupe";
            this.NumGroupe.Size = new System.Drawing.Size(235, 30);
            this.NumGroupe.TabIndex = 28;
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(45, 84);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(52, 23);
            this.guna2HtmlLabel5.TabIndex = 29;
            this.guna2HtmlLabel5.Text = "Filiere : ";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(45, 175);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(62, 23);
            this.guna2HtmlLabel6.TabIndex = 30;
            this.guna2HtmlLabel6.Text = "Groupe :";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(48, 125);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(59, 23);
            this.guna2HtmlLabel7.TabIndex = 31;
            this.guna2HtmlLabel7.Text = "Niveau :";
            // 
            // NumAnne
            // 
            this.NumAnne.BackColor = System.Drawing.Color.Transparent;
            this.NumAnne.BorderRadius = 11;
            this.NumAnne.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NumAnne.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NumAnne.Location = new System.Drawing.Point(195, 125);
            this.NumAnne.Name = "NumAnne";
            this.NumAnne.Size = new System.Drawing.Size(160, 30);
            this.NumAnne.TabIndex = 32;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(374, 125);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(43, 23);
            this.guna2HtmlLabel8.TabIndex = 33;
            this.guna2HtmlLabel8.Text = "année";
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Name = "Student";
            this.Size = new System.Drawing.Size(1080, 703);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            this.guna2GroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picEtud)).EndInit();
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumAge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumGroupe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAnne)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2Button delete;
        private Guna.UI2.WinForms.Guna2Button update;
        private Guna.UI2.WinForms.Guna2Button add;
        private Guna.UI2.WinForms.Guna2TextBox Tcne;
        private Guna.UI2.WinForms.Guna2TextBox Tadresse;
        private Guna.UI2.WinForms.Guna2TextBox Temail;
        private Guna.UI2.WinForms.Guna2TextBox Tcin;
        private Guna.UI2.WinForms.Guna2TextBox Tp;
        private Guna.UI2.WinForms.Guna2TextBox Tn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2ImageRadioButton women;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2NumericUpDown NumAge;
        private Guna.UI2.WinForms.Guna2ImageRadioButton man;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2DateTimePicker dateN;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2ComboBox combVille;
        private Guna.UI2.WinForms.Guna2TextBox Ttell;
        private Guna.UI2.WinForms.Guna2PictureBox picEtud;
        private Guna.UI2.WinForms.Guna2Button upload;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2NumericUpDown NumGroupe;
        private Guna.UI2.WinForms.Guna2ComboBox combFilier;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2NumericUpDown NumAnne;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
    }
}
