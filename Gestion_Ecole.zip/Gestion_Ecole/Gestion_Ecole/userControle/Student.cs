﻿using Gestion_Ecole.classes;
using Gestion_Ecole.services;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Ecole.userControle
{
    public partial class Student : UserControl
    {
        EtudService st = new EtudService();
        FilierService filierServ= new FilierService();
        MySqlConnection con = new MySqlConnection("SERVER=127.0.0.1; DATABASE=gestion_ecole; UID=root; PASSWORD=");
        byte[] img;
        DataTable dataTable;
        static int id;
        String nomfiliere;

        public Student()
        {
            InitializeComponent();
            remplirFilieresModule();
            remplirVille();
        }

        public String SexeCheck()
        {
            String s="default";
            if (man.Checked)
                s="homme";
           else if (women.Checked)
                s="femme";
            
            return s;
        }

        public void remplirFilieresModule()
        {
            combFilier.Items.Clear();
            if (con.State != ConnectionState.Open) { con.Open(); }
            MySqlCommand cmd = new MySqlCommand("select nom from filiere",con);
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                combFilier.Items.Add(reader[0]);

            }
            con.Close();
        }
        public void remplirVille()
        {
            combVille.Items.Clear();
            if (con.State != ConnectionState.Open) { con.Open(); }
            MySqlCommand cmd = new MySqlCommand("select ville from ville", con);
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                combVille.Items.Add(reader[0]);

            }
            con.Close();
        }

        private void upload_Click(object sender, EventArgs e)
        {
            Image image;
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                // ofd.Filter = "All Files |*.*|JPG|*.jpg|PNG|*.png";
                ofd.Filter = "All Files(*.jpg;*.png;*.gif;*.jpeg;*.pdf) | *.jpg;*.png;*.gif;*.jpeg;*.pdf";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    picEtud.Image = Image.FromFile(ofd.FileName);
                    image = Image.FromFile(ofd.FileName); ;
                    var ms = new MemoryStream();
                    image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                    byte[] i = ms.ToArray();
                    img = i;
                }
                else
                {

                }

            }
            catch (Exception ex)
            {

            }
        }

        private void add_Click(object sender, EventArgs e)
        {


            String email = Temail.Text.ToString();
            if (email == "" || !(email.Contains("@")))
            {
                Temail.BorderColor= Color.Red;
                return;
            }

            String nom = Tn.Text.ToString();
            String prenom = Tp.Text.ToString();
            int age = int.Parse(NumAge.Value.ToString());

            string pattern = "^[0-9]{10}$";
            Regex reg = new Regex(pattern);

            String tell = Ttell.Text.ToString();
            if (tell == "" || !reg.IsMatch(tell))
            {
              Ttell.BorderColor= Color.Red;
                return;

            }
            String address = Tadresse.Text.ToString();
            String sexe = SexeCheck();
            String cne = Tcne.Text.ToString();
            String cin = Tcin.Text.ToString();
            String dateNais = dateN.ToString();
            String villeO = combVille.SelectedItem.ToString();
            byte[] image = img;
            int nv = int.Parse(NumAnne.Value.ToString());

            String  nameF = combFilier.SelectedItem.ToString();

            int id_filiere = filierServ.getFilierbyNom(nameF);
            int num_gr=  int.Parse( NumGroupe.Value.ToString());

            DialogResult dialogClose = MessageBox.Show("Ajouter ?", "Attention!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);

            if (dialogClose == DialogResult.OK)
            {
                StudentC stud = new StudentC(nom,prenom,cin,cne,email,age,sexe,dateNais,villeO,tell,address,image,id_filiere,nv,num_gr);
                st.ajouter(stud);
            }
        }
    }
}
