﻿namespace Gestion_Ecole
{
    partial class Etudiant
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Tn = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tp = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tc = new Guna.UI2.WinForms.Guna2TextBox();
            this.Te = new Guna.UI2.WinForms.Guna2TextBox();
            this.Ta = new Guna.UI2.WinForms.Guna2TextBox();
            this.Tt = new Guna.UI2.WinForms.Guna2TextBox();
            this.dateN = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.picEtud = new Guna.UI2.WinForms.Guna2PictureBox();
            this.add = new Guna.UI2.WinForms.Guna2Button();
            this.update = new Guna.UI2.WinForms.Guna2Button();
            this.delete = new Guna.UI2.WinForms.Guna2Button();
            this.clear = new Guna.UI2.WinForms.Guna2Button();
            this.upload = new Guna.UI2.WinForms.Guna2Button();
            this.combVille = new System.Windows.Forms.ComboBox();
            this.combGenre = new System.Windows.Forms.ComboBox();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEtud)).BeginInit();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.dataGridView1);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(1121, 317);
            this.guna2Panel1.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(36, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1034, 265);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Tn
            // 
            this.Tn.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tn.DefaultText = "";
            this.Tn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tn.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tn.Location = new System.Drawing.Point(36, 50);
            this.Tn.Name = "Tn";
            this.Tn.PasswordChar = '\0';
            this.Tn.PlaceholderText = "Nom ";
            this.Tn.SelectedText = "";
            this.Tn.Size = new System.Drawing.Size(177, 28);
            this.Tn.TabIndex = 5;
            // 
            // Tp
            // 
            this.Tp.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tp.DefaultText = "";
            this.Tp.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tp.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tp.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tp.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tp.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tp.Location = new System.Drawing.Point(258, 50);
            this.Tp.Name = "Tp";
            this.Tp.PasswordChar = '\0';
            this.Tp.PlaceholderText = "Prenom";
            this.Tp.SelectedText = "";
            this.Tp.Size = new System.Drawing.Size(177, 28);
            this.Tp.TabIndex = 6;
            // 
            // Tc
            // 
            this.Tc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tc.DefaultText = "";
            this.Tc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tc.Location = new System.Drawing.Point(36, 109);
            this.Tc.Name = "Tc";
            this.Tc.PasswordChar = '\0';
            this.Tc.PlaceholderText = "CIN";
            this.Tc.SelectedText = "";
            this.Tc.Size = new System.Drawing.Size(177, 28);
            this.Tc.TabIndex = 7;
            // 
            // Te
            // 
            this.Te.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Te.DefaultText = "";
            this.Te.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Te.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Te.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Te.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Te.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Te.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Te.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Te.Location = new System.Drawing.Point(36, 165);
            this.Te.Name = "Te";
            this.Te.PasswordChar = '\0';
            this.Te.PlaceholderText = "Email";
            this.Te.SelectedText = "";
            this.Te.Size = new System.Drawing.Size(399, 28);
            this.Te.TabIndex = 8;
            // 
            // Ta
            // 
            this.Ta.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Ta.DefaultText = "";
            this.Ta.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Ta.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Ta.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Ta.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Ta.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Ta.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Ta.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Ta.Location = new System.Drawing.Point(36, 213);
            this.Ta.Name = "Ta";
            this.Ta.PasswordChar = '\0';
            this.Ta.PlaceholderText = "Adresse";
            this.Ta.SelectedText = "";
            this.Ta.Size = new System.Drawing.Size(399, 28);
            this.Ta.TabIndex = 9;
            // 
            // Tt
            // 
            this.Tt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Tt.DefaultText = "";
            this.Tt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Tt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Tt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Tt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tt.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Tt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Tt.Location = new System.Drawing.Point(258, 109);
            this.Tt.Name = "Tt";
            this.Tt.PasswordChar = '\0';
            this.Tt.PlaceholderText = "Tell";
            this.Tt.SelectedText = "";
            this.Tt.Size = new System.Drawing.Size(177, 28);
            this.Tt.TabIndex = 10;
            // 
            // dateN
            // 
            this.dateN.BackColor = System.Drawing.Color.Transparent;
            this.dateN.Checked = true;
            this.dateN.FillColor = System.Drawing.Color.White;
            this.dateN.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dateN.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.dateN.Location = new System.Drawing.Point(36, 284);
            this.dateN.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dateN.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dateN.Name = "dateN";
            this.dateN.Size = new System.Drawing.Size(399, 36);
            this.dateN.TabIndex = 11;
            this.dateN.Value = new System.DateTime(2023, 1, 6, 21, 3, 20, 883);
            // 
            // picEtud
            // 
            this.picEtud.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picEtud.ImageRotate = 0F;
            this.picEtud.Location = new System.Drawing.Point(500, 50);
            this.picEtud.Name = "picEtud";
            this.picEtud.Size = new System.Drawing.Size(227, 203);
            this.picEtud.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEtud.TabIndex = 12;
            this.picEtud.TabStop = false;
            this.picEtud.Click += new System.EventHandler(this.picEtud_Click);
            // 
            // add
            // 
            this.add.BorderRadius = 20;
            this.add.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.add.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.add.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.add.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.add.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.add.ForeColor = System.Drawing.Color.White;
            this.add.Location = new System.Drawing.Point(935, 50);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(135, 45);
            this.add.TabIndex = 13;
            this.add.Text = "Ajouter";
            this.add.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // update
            // 
            this.update.BorderRadius = 20;
            this.update.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.update.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.update.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.update.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.update.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.update.ForeColor = System.Drawing.Color.White;
            this.update.Location = new System.Drawing.Point(935, 109);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(135, 45);
            this.update.TabIndex = 16;
            this.update.Text = "Modifier";
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // delete
            // 
            this.delete.BorderRadius = 20;
            this.delete.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.delete.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.delete.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.delete.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.delete.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.delete.ForeColor = System.Drawing.Color.White;
            this.delete.Location = new System.Drawing.Point(935, 176);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(135, 45);
            this.delete.TabIndex = 17;
            this.delete.Text = "Supprimer";
            // 
            // clear
            // 
            this.clear.BorderRadius = 20;
            this.clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clear.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.clear.ForeColor = System.Drawing.Color.White;
            this.clear.Location = new System.Drawing.Point(960, 278);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(85, 39);
            this.clear.TabIndex = 18;
            this.clear.Text = "Clear";
            // 
            // upload
            // 
            this.upload.BorderRadius = 20;
            this.upload.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.upload.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.upload.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.upload.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.upload.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.upload.ForeColor = System.Drawing.Color.White;
            this.upload.Location = new System.Drawing.Point(533, 278);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(139, 33);
            this.upload.TabIndex = 19;
            this.upload.Text = "Upload";
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // combVille
            // 
            this.combVille.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combVille.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combVille.FormattingEnabled = true;
            this.combVille.Location = new System.Drawing.Point(258, 363);
            this.combVille.Name = "combVille";
            this.combVille.Size = new System.Drawing.Size(177, 21);
            this.combVille.TabIndex = 25;
            // 
            // combGenre
            // 
            this.combGenre.FormattingEnabled = true;
            this.combGenre.Items.AddRange(new object[] {
            "homme",
            "femme"});
            this.combGenre.Location = new System.Drawing.Point(36, 363);
            this.combGenre.Name = "combGenre";
            this.combGenre.Size = new System.Drawing.Size(177, 21);
            this.combGenre.TabIndex = 26;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.textBox1);
            this.guna2Panel2.Controls.Add(this.combGenre);
            this.guna2Panel2.Controls.Add(this.combVille);
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel3);
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel2);
            this.guna2Panel2.Controls.Add(this.guna2HtmlLabel1);
            this.guna2Panel2.Controls.Add(this.upload);
            this.guna2Panel2.Controls.Add(this.clear);
            this.guna2Panel2.Controls.Add(this.delete);
            this.guna2Panel2.Controls.Add(this.update);
            this.guna2Panel2.Controls.Add(this.add);
            this.guna2Panel2.Controls.Add(this.picEtud);
            this.guna2Panel2.Controls.Add(this.dateN);
            this.guna2Panel2.Controls.Add(this.Tt);
            this.guna2Panel2.Controls.Add(this.Ta);
            this.guna2Panel2.Controls.Add(this.Te);
            this.guna2Panel2.Controls.Add(this.Tc);
            this.guna2Panel2.Controls.Add(this.Tp);
            this.guna2Panel2.Controls.Add(this.Tn);
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 317);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1121, 433);
            this.guna2Panel2.TabIndex = 1;
            this.guna2Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel2_Paint);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(533, 109);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(179, 20);
            this.textBox1.TabIndex = 27;
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(258, 339);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(39, 18);
            this.guna2HtmlLabel3.TabIndex = 24;
            this.guna2HtmlLabel3.Text = "Ville :";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(36, 339);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(47, 18);
            this.guna2HtmlLabel2.TabIndex = 23;
            this.guna2HtmlLabel2.Text = "Genre :";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(36, 260);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(122, 18);
            this.guna2HtmlLabel1.TabIndex = 20;
            this.guna2HtmlLabel1.Text = "Date de naissance :";
            // 
            // Etudiant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.Name = "Etudiant";
            this.Size = new System.Drawing.Size(1121, 750);
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEtud)).EndInit();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2TextBox Tn;
        private Guna.UI2.WinForms.Guna2TextBox Tp;
        private Guna.UI2.WinForms.Guna2TextBox Tc;
        private Guna.UI2.WinForms.Guna2TextBox Te;
        private Guna.UI2.WinForms.Guna2TextBox Ta;
        private Guna.UI2.WinForms.Guna2TextBox Tt;
        private Guna.UI2.WinForms.Guna2DateTimePicker dateN;
        private Guna.UI2.WinForms.Guna2PictureBox picEtud;
        private Guna.UI2.WinForms.Guna2Button add;
        private Guna.UI2.WinForms.Guna2Button update;
        private Guna.UI2.WinForms.Guna2Button delete;
        private Guna.UI2.WinForms.Guna2Button clear;
        private Guna.UI2.WinForms.Guna2Button upload;
        private System.Windows.Forms.ComboBox combVille;
        private System.Windows.Forms.ComboBox combGenre;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private System.Windows.Forms.TextBox textBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}
